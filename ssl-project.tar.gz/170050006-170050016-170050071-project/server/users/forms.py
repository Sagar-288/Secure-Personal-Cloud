from db_file_storage.form_widgets import DBClearableFileInput
from django.contrib.auth.models import User
from django import forms

from users.models import *


class UserForm(forms.ModelForm):
    password1 = forms.CharField(widget=forms.PasswordInput, label="Password")
    password2 = forms.CharField(widget=forms.PasswordInput, label="Confirm Password")
    first_name = forms.CharField(max_length=30)
    last_name = forms.CharField(max_length=30)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'password1', 'password2']


class FolderForm(forms.ModelForm):

    class Meta:
        model = Folder
        fields = ['name']


class FileForm(forms.ModelForm):
    class Meta:
        model = File
        fields = ['name', 'data', 'type', 'md5', 'encmd5', 'size']
        exclude = []
        widgets = {
            'picture': DBClearableFileInput
        }
