from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import render, redirect, get_object_or_404
from .forms import *
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib import messages
from .models import Folder, File
from api.models import Status
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
import time
import hashlib
from django.http import HttpResponse

# Create your views here.

@csrf_exempt
def index(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    else:
        user = request.user
        root = user.folder_set.get(root=True)
        return findex(request, root.pk)

@csrf_exempt
def findex(request, f_id):
    if not request.user.is_authenticated:
        return redirect('login_user')
    else:
        user = request.user
        status = user.status_set.all()[0]
        folder = get_object_or_404(Folder, pk=f_id)
        if folder.user != user:
            return redirect('home')
        else:
            folderform = FolderForm(None)
            fileform = FileForm(None)
            path = folder.path.split(',')
            ancestors = []
            for i in path:
                if i!='':
                    ancestors = ancestors + [Folder.objects.get(id=i)]

            context = {'parent': folder,
                       'folderform': folderform,
                       'fileform': fileform,
                       'ancestors': ancestors,
                       'empty': len(folder.folder_set.all()) + len(folder.file_set.all()),
                       'schema': status.schema,
                       'pwdmd5': status.pwdmd5}
            return render(request, 'users/index.html', context)

@csrf_exempt
def newFolder(request, f_id):
    if not request.user.is_authenticated:
        return redirect('login_user')
    user = request.user
    parent = get_object_or_404(Folder, pk=f_id)
    if parent.user != user:
        return redirect('home')

    form = FolderForm(request.POST or None)
    if form.is_valid():
        folder = form.save(commit=False)
        folder.path = parent.path + ',' + str(f_id)
        folder.user = request.user
        folder.parent = parent
        folder.save()
    return redirect('change_directory', f_id=f_id)


@csrf_exempt
def newFile(request, f_id):
    if not request.user.is_authenticated:
        return redirect('login_user')
    user = request.user
    parent = get_object_or_404(Folder, pk=f_id)
    if parent.user != user:
        return redirect('home')

    form = FileForm(request.POST, request.FILES)
    if form.is_valid():
        file = form.save(commit=False)
        file.parent = parent
        cfile = request.FILES['data']
        cmd5 = hashlib.md5(cfile.read()).hexdigest()
        file.verifymd5 = 'close'
        if cmd5 == file.encmd5:
            file.verifymd5 = 'check'
        file.save()
    return HttpResponse(file.verifymd5)


# @csrf_exempt
# def downloadFile(request, file_id):



def deleteFolder(request, f_id):
    if not request.user.is_authenticated:
        return redirect('login_user')
    user = request.user
    folder = get_object_or_404(Folder, pk=f_id)
    if folder.user != user:
        return redirect('home')

    parent = folder.parent
    folder.delete()
    return redirect('change_directory', f_id=parent.id)


def deleteFile(request, file_id):
    if not request.user.is_authenticated:
        return redirect('login_user')
    user = request.user
    file = File.objects.get(id=file_id)
    folder = file.parent
    if folder.user != user:
        return redirect('home')

    file.delete()
    return redirect('change_directory', f_id=folder.pk)


@csrf_exempt
def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect('home')
            else:
                return render(request, 'users/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'users/login.html', {'error_message': 'Invalid credentials'})
    return render(request, 'users/login.html')


def logout_user(request):
    logout(request)
    return redirect('login_user')


@csrf_exempt
def register(request):
    form = UserForm(request.POST or None)
    if form.is_valid():
        if form['password1'].value() == form['password2'].value():
            user = form.save(commit=False)
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            form.cleaned_data['password2']
            user.set_password(password)
            user.save()
            user = authenticate(username=username, password=password)
            folder = Folder()
            folder.name = 'Home'
            folder.user = user
            folder.root = True
            folder.path = ''
            folder.save()
            folder.parent=None
            folder.save()
            status = Status()
            status.user=user
            now_timestamp = time.time()
            offset = datetime.fromtimestamp(now_timestamp) - datetime.utcfromtimestamp(now_timestamp)
            status.synctime=str(datetime.now()+offset)
            status.lock=0
            status.pwdmd5=None
            status.schema=None
            status.save()
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect('home')
        else:
            form.add_error('password1', 'Passwords do not match')
    return render(request, 'users/register.html', {'form': form})


@csrf_exempt
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('home')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'users/change_password.html', {
        'form': form
    })

