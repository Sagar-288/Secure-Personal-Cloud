from . import views
from django.conf.urls import url
from django.urls import path, include


urlpatterns = [
    path('login/', views.login_user, name='login_user'),
    path('logout/', views.logout_user, name='logout_user'),
    path('register/', views.register, name='register'),
    path('change_password/', views.change_password, name='change_password'),
    path('', views.index, name="home"),
    url(r'^folders/(?P<f_id>[0-9]+)/$', views.findex, name='change_directory'),
    url(r'^newfolder/(?P<f_id>[0-9]+)/$', views.newFolder, name='newfolder'),
    url(r'^newfile/(?P<f_id>[0-9]+)/$', views.newFile, name='newfile'),
    url(r'^deleteFolder/(?P<f_id>[0-9]+)/$', views.deleteFolder, name='deletefolder'),
    url(r'^deleteFile/(?P<file_id>[0-9]+)/$', views.deleteFile, name='deletefile'),
    # url(r'^downloadFile/(?P<file_id>[0-9]+)/$', views.downloadFile, name='downloadfile'),
]