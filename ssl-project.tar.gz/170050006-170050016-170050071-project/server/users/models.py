from db_file_storage.model_utils import delete_file_if_needed, delete_file
from django.db import models
from django.contrib.auth.models import User


class Folder(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    name = models.CharField(max_length=50)
    root = models.BooleanField(default=False)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null= True)
    path = models.CharField(max_length=200, default='')
    datetime = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class File(models.Model):
    parent = models.ForeignKey(Folder, on_delete=models.CASCADE, blank=True, null=True)
    name = models.CharField(max_length=150, blank=True, null=True)
    data = models.FileField(upload_to='users.FileStorage/bytes/filename/mimetype', blank=True, null=True)
    datetime = models.DateTimeField(auto_now=True)
    type = models.CharField(max_length=150, blank=True, null=True)
    md5 = models.CharField(max_length=64, blank=True, null=True)
    encmd5 = models.CharField(max_length=64, blank=True, null=True)
    verifymd5 = models.CharField(max_length=200, blank=True, null=True)
    size = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        delete_file_if_needed(self, 'data')
        super(File, self).save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        delete_file(self, 'data')
        super(File, self).delete(*args, **kwargs)


class FileStorage(models.Model):
    bytes = models.TextField()
    filename = models.CharField(max_length=255)
    mimetype = models.CharField(max_length=50)
