from django.conf.urls import url, include
from .views import *

urlpatterns = [
    url(r'^$', HomeView, name='apiHome'),
    url(r'^(?P<pk>\d+)/$', FolderView.as_view(), name='api'),
    url(r'^rest-auth/', include('rest_auth.urls')),
    url(r'^getstatus/$', StatusView.as_view(), name='getstatus'),
    url(r'^setstatus/$', setstatus, name='setstatus')
]