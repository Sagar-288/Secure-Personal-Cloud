from django.shortcuts import render, redirect
from rest_framework.response import Response
from rest_framework.views import APIView
from django.http import HttpResponse
from users.models import Folder, File
from django.core import serializers
from django.urls import reverse, reverse_lazy
from django.views.decorators.csrf import csrf_exempt
from api.forms import StatusForm



def HomeView(request):
    if not request.user.is_authenticated:
        return redirect('login_user')
    return redirect('api', pk=request.user.folder_set.get(root=True).id)


class FolderView(APIView):

    def get(self, request, format=None, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login_user')

        folder = Folder.objects.get(pk=kwargs['pk'])

        if folder.user != request.user:
            return redirect('apiHome')

        if folder.root:
            folder.parent=folder

        parent_url = request.build_absolute_uri(reverse('api', args=[folder.parent.pk]))
        upload_folder = request.build_absolute_uri(reverse('newfolder', args=[folder.pk]))
        upload_file = request.build_absolute_uri(reverse('newfile', args=[folder.pk]))

        folderlist = folder.folder_set.all().order_by('name')
        folders = []
        for fold in folderlist:
            folder_url = request.build_absolute_uri(reverse('api', args=[fold.pk]))
            delete_url = request.build_absolute_uri(reverse('deletefolder', args=[fold.pk]))
            folders.append({'name': fold.name,
                            'time':fold.datetime,
                         'folder_url': folder_url,
                         'delete_url': delete_url})

        filelist = folder.file_set.all().order_by('name')
        files = []
        for file in filelist:
            delete_url = request.build_absolute_uri(reverse('deletefile', args=[file.pk]))
            download_url = request.build_absolute_uri(reverse('db_file_storage.download_file')) \
                           + '?name=' \
                           + str(file.data)
            files.append({'name': file.name,
                          'time': file.datetime,
                          'md5': file.md5,
                          'size': file.size,
                       'download_url': download_url,
                       'delete_url': delete_url})

        return Response({'name': folder.name,
                         'id': folder.id,
                         'parent_url': parent_url,
                         'new_folder': upload_folder,
                         'upload_file': upload_file,
                         'folders': folders,
                         'files': files})


class StatusView(APIView):

    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login_user')

        status = request.user.status_set.all()[0]

        return Response({'synctime': status.synctime,
                         'lock': status.lock,
                         'pwdmd5': status.pwdmd5,
                         'schema': status.schema})

@csrf_exempt
def setstatus(request):
    if not request.user.is_authenticated:
        return HttpResponse("Bad User")

    form = StatusForm(request.POST or None)

    status = request.user.status_set.all()[0]

    if form.is_valid():
        s = form.save(commit=False)
        if (s.lock is not None):
            status.lock = s.lock
        if(s.pwdmd5 is not None):
            status.pwdmd5 = s.pwdmd5
        if(s.schema is not None):
            status.schema = s.schema
        if(s.synctime is not None):
            status.synctime = s.synctime
        status.save()

        return HttpResponse("Done")

    return HttpResponse("Failed")
