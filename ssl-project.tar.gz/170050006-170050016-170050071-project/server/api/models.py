from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Status(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    synctime = models.CharField(max_length=100, null=True, blank=True)
    schema = models.CharField(max_length=255, null=True, blank=True)
    lock = models.CharField(max_length=1, null=True, blank=True)
    pwdmd5 = models.CharField(max_length=32, null=True, blank=True)
