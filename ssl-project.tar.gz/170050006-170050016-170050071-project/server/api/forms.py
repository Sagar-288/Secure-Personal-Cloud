from django import forms
from api.models import Status

class StatusForm(forms.ModelForm):
    class Meta:
        model = Status
        fields = ['synctime', 'lock', 'pwdmd5', 'schema']