# secure-personal-cloud

1) open terminal and run "python3 manage.py runserver <IP>"
2) now open the website url in a browser
3) once the server is running linux client can be used to send requests to server and to do synchronizations 
