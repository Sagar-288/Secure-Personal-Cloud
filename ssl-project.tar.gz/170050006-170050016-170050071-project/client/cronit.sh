#!/bin/bash
if zenity --width="200" --height="100" --question --text="Press Yes to start periodic sync"; then
	cd ~/bin
	konsole -e 'bash -c "python3 spc sync; bash"'
else
	zenity --error --text="Sync Aborted"
fi