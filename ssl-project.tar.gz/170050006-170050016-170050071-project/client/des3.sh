# key="098F6BCD"
# openssl enc -des-cbc -A -base64 -in text.txt -K $key -iv '00000000'
if [ $1 -eq '1' ]; then 
	openssl enc -des-cbc -A -base64 -in $2 -out thisout.txt -K $3 -iv '00000000'
	# echo 'there'
else
	openssl enc -des-cbc -d -A -base64 -in $2 -out here.txt -K $3 -iv '00000000'
fi 