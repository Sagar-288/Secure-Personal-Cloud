1) run bash spc-download.sh
2) run bash installman.sh
3) run crontab cronjob.cron