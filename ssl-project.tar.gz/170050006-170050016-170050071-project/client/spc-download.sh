#!/bin/bash
mkdir -p ~/bin
cp spc ~/bin
cd ~
echo 'export PATH=$PATH":$HOME/bin"'>>.profile
source .profile