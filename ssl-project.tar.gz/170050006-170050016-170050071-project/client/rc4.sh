if [ $1 -eq '1' ]; then 
	openssl enc -rc4 -A -base64 -in $2 -out thisout.txt -K $3
	# echo 'there'
else
	openssl enc -rc4 -d -A -base64 -in $2 -out here.txt -K $3
fi 