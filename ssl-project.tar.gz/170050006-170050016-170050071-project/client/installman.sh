#!/bin/bash
echo ".\" Manpage for spc.
.TH man "1.0" "spc man page"
.SH NAME
spc \- Linux command to interact with your secure personal cloud
.SH SYNOPSIS
spc [OPTION]
.SH DESCRIPTION
spc is a command line tool that logs in to one's secure personal cloud and can upload,downlaod files and folders as well as sync files and folders.  
.SH OPTIONS
spc takes follwing options :
.PP
version
.PP
	displays current version
.PP
help
.PP
	about spc and its commands
.PP
server
.PP
	to get the ip address and port number of the server
.PP
config-edit
.PP
	to add/update username and password
.PP
set-url
.PP
	to set the url for the spc homepage
.PP 
sync
	to synchronize files and folders on server and client
.PP
en-de-update
.PP
	to update encryption schema
.PP
observe-dir
.PP
	to set observed directory
.PP
en-de-list
.PP
	to list available encryption schemes
.PP
observed-dir
.PP
	to check which directory has been observed
.PP
Cur-Schema
.PP
	to get the current schema
.PP
.SH BUGS
Looking
.SH AUTHOR
CHMOD251" >> spc
x=$(pwd)
cd /usr/local/man
sudo mkdir -p man1
cd $x
sudo mv spc /usr/local/man/man1/spc.1
sudo gzip /usr/local/man/man1/spc.1