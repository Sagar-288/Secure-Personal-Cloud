import os, sys, io
from os.path import expanduser
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto import Random
import base64, binascii
import os
class PKCS7Encoder():
    class InvalidBlockSizeError(Exception):
        pass

    def __init__(self, block_size=16):
        if block_size < 2 or block_size > 255:
            raise PKCS7Encoder.InvalidBlockSizeError('The block size must be ' \
                    'between 2 and 255, inclusive')
        self.block_size = block_size

    def encode(self, text):
        text_length = len(text)
        amount_to_pad = self.block_size - (text_length % self.block_size)
        if amount_to_pad == 0:
            amount_to_pad = self.block_size
        pad = chr(amount_to_pad)
        return text + pad * amount_to_pad

    def decode(self, text):
        pad = ord(text[-1])
        return text[:-pad]

class myAES():
    def encrypt(self, filename,r):
        x = open(filename,'rb')
        os.system('bash aes.sh '+filename)
        y = open('out.txt','r').read()
        os.remove('out.txt')
        key = r['key']
        # fi = open('sb64.txt','w')
        # fi.write(y)
        # chunk_size = 112
        # key = '1234567890123456'
        IV = b'\x14U\xa5s\x01\xfab\xe6R_\x86\xdaM\x91V\xa1'
        encoder = PKCS7Encoder()
        encryptor = AES.new(key, AES.MODE_CBC, IV, segment_size=128)
        data = ''.encode()
        raw = encoder.encode(y)
        data +=  encryptor.encrypt(raw)
        # f2 = open("enc.txt", 'wb')
        # f2.write(base64.b64encode(IV + data))
        return base64.b64encode(IV + data)

    def decrypt(self,r,encrypted):
        key = r['key']
        encrypted = base64.b64decode(encrypted)
        IV = encrypted[:16]
        aes = AES.new(key, AES.MODE_CBC, IV, segment_size=128)
        encoder= PKCS7Encoder()
        raw=aes.decrypt(encrypted[16:]).decode('ascii')
        return base64.b64decode(encoder.decode(raw))
